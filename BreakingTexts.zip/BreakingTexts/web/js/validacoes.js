
function validarCNPJ() {
    cnpjEscola = document.getElementById("cnpj").value;
    

    if (cnpjEscola == '')
        alert("CNPJ inválido");

    if (cnpjEscola.length !== 18)
        alert("CNPJ inválido");

    // Elimina CNPJs invalidos conhecidos
    if (cnpjEscola === "00.000.000/0000-00" ||
            cnpjEscola === "11.111.111/1111-11" ||
            cnpjEscola === "22.222.222/2222-22" ||
            cnpjEscola === "33.333.333/3333-33" ||
            cnpjEscola === "44.444.444/4444-44" ||
            cnpjEscola === "55.555.555/5555-55" ||
            cnpjEscola === "66.666.666/6666-66" ||
            cnpjEscola === "77.777.777/7777-77" ||
            cnpjEscola === "88.888.888/8888-88" ||
            cnpjEscola === "99.999.999/9999-99")
        // Valida DVs
        tamanho = cnpjEscola.length - 2
    numeros = cnpjEscola.substring(0, tamanho);
    digitos = cnpjEscola.substring(tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2)
            pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(0))
        alert("CNPJ inválido");

    tamanho = tamanho + 1;
    numeros = cnpjEscola.substring(0, tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2)
            pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(1))
        alert("CNPJ inválido");

    return true;

}

function formatarCampo(campoTexto) {
    if (campoTexto.value.length <= 11) {
        campoTexto.value = mascaraCpf(campoTexto.value);
    } else {
        campoTexto.value = mascaraCnpj(campoTexto.value);
    }
}
function retirarFormatacao(campoTexto) {
    campoTexto.value = campoTexto.value.replace(/(\.|\/|\-)/g, "");
}
function mascaraCpf(valor) {
    return valor.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/g, "\$1.\$2.\$3\-\$4");
}
function mascaraCnpj(valor) {
    return valor.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/g, "\$1.\$2.\$3\/\$4\-\$5");
}



function validarSenha() {
    submit = document.getElementById("enviar");
    submit.disabled = true;
    senha = document.getElementById("senha").value;
    confirmarSenha = document.getElementById("confirmarSenha").value;

    if (senha === "" || confirmarSenha === "") {
        alert("Os campos referentes à senha não podem estar vazios");
        submit.disabled = true;
    } else if (senha !== confirmarSenha) {
        alert("As senhas digitadas são incoerentes, tente novamente");
        submit.disabled = true;
    } else {
        submit.disabled = false;

        return true;
    }
}

function verificarTexto(){
    var pont = Document.getElementById("pontuacaoTexto").value;
    
    if(pont !== ""){
        document.write("Você já corrigiu esse texto");
        return false;
    }else{
        return true;
    }
}







