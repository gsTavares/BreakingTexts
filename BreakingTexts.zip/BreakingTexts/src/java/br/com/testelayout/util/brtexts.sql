
CREATE TABLE usuario(
idusuario serial not null,
nomeusuario varchar(150) not null,
senhausuario varchar(25) not null,
tipousuario varchar(9) not null,

CONSTRAINT pk_usuario PRIMARY KEY (idusuario)
);


CREATE TABLE professor(
idprofessor serial not null,
idusuario int not null,
nomeprofessor varchar(500) not null,
idadeprofessor integer not null,
cpfprofessor varchar(14) not null,
statusprofessor varchar(150),

CONSTRAINT pk_professor PRIMARY KEY (idprofessor),
CONSTRAINT fk_usuario FOREIGN KEY (idusuario) REFERENCES usuario(idusuario)
);

CREATE TABLE escola(
idescola serial not null,
idusuario int not null,
cnpjescola varchar(18) not null,
nomeescola varchar(500) not null,
estadoescola char(2) not null,
cidadeescola varchar(200) not null,

CONSTRAINT pk_escola PRIMARY KEY (idescola),
CONSTRAINT fk_usuario FOREIGN KEY (idusuario) REFERENCES usuario(idusuario)
);

CREATE TABLE turma(
idturma serial not null,
idprofessor integer,
idescola integer,
nometurma varchar(200),
quantidadealunosturma varchar(2),


CONSTRAINT pk_turma PRIMARY KEY (idturma),
CONSTRAINT fk_professor FOREIGN KEY (idprofessor) REFERENCES professor,
CONSTRAINT fk_escola FOREIGN KEY (idescola) REFERENCES escola(idescola)
);

CREATE TABLE material(
idmaterial serial not null,
idprofessor integer not null,
idturma integer not null,
tipomaterial varchar(100) not null,
titulomaterial varchar(200),
caminhomaterial varchar(2000) not null,

CONSTRAINT pk_material PRIMARY KEY (idmaterial),
CONSTRAINT fk_professor FOREIGN KEY (idprofessor) REFERENCES professor(idprofessor),
CONSTRAINT fk_turma FOREIGN KEY (idturma) REFERENCES turma(idturma)
);



CREATE TABLE aluno(
idaluno serial not null,
idusuario int not null,
raaluno varchar(100) not null,
datanascaluno date not null,
idturma integer,
nomealuno varchar(500) not null,
statusaluno varchar(50),


CONSTRAINT pk_aluno PRIMARY KEY (idaluno),
CONSTRAINT fk_usuario FOREIGN KEY (idusuario) REFERENCES usuario(idusuario),
CONSTRAINT fk_turma FOREIGN KEY (idturma) REFERENCES turma(idturma)
);

CREATE TABLE atividade(
idatividade serial not null,
idprofessor integer,
idturma integer,
nomeatividade varchar(150) not null,
temaatividade varchar(250) not null,
descricaoatividade varchar(1500),
dataatividade date not null,
statusdoprofessor varchar(150),
pontuacaoatividade numeric(3,1),


CONSTRAINT pk_atividade PRIMARY KEY (idatividade),
CONSTRAINT fk_professor FOREIGN KEY (idprofessor) REFERENCES professor,
CONSTRAINT fk_turma FOREIGN KEY (idturma) REFERENCES turma(idturma)
);

CREATE TABLE texto(
idtexto serial not null,
idaluno integer,
idatividade integer,
titulotexto varchar(150),
caminhotexto varchar(2000) not null,
comentariotexto varchar(2000),
pontuacaotexto numeric(3,1),
dataenviotexto date not null,
statuscorrecao varchar(100) not null,

CONSTRAINT pk_texto PRIMARY KEY (idtexto),
CONSTRAINT fk_aluno FOREIGN KEY (idaluno) REFERENCES aluno,
CONSTRAINT fk_atividade FOREIGN KEY (idatividade) REFERENCES atividade
);

CREATE TABLE desempenho(
iddesempenho serial not null,
idturma integer not null,
mediadesempenho numeric(3,1),
nometurma varchar (150),

CONSTRAINT pk_desempenho PRIMARY KEY(iddesempenho),
CONSTRAINT fk_turma FOREIGN KEY (idturma) REFERENCES turma
);

CREATE TABLE professor_escola(
idprofessorescola serial not null,
idprofessor integer,
idescola integer,

CONSTRAINT pk_professorescola PRIMARY KEY (idprofessorescola),
CONSTRAINT fk_professor FOREIGN KEY (idprofessor) REFERENCES professor,
CONSTRAINT fk_escola FOREIGN KEY (idescola) REFERENCES escola
);





