/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.model;
import java.util.Date;
/**
 *
 * @author PICHAU
 */
public class Atividade {
    private Integer idAtividade;
    private Integer idProfessor;
    private Integer idTurma;
    private String nomeAtividade;
    private String temaAtividade;
    private String descricaoAtividade;
    private Date dataAtividade;
    private String statusDoProfessor;
    
    private Double pontuacaoAtividade;
    
    public Atividade(){
        
    }

    public Atividade(Integer idAtividade, Integer idProfessor, Integer idTurma, String nomeAtividade, String temaAtividade, String descricaoAtividade, Date dataAtividade, String statusDoProfessor, Double pontuacaoAtividade) {
        this.idAtividade = idAtividade;
        this.idProfessor = idProfessor;
        this.idTurma = idTurma;
        this.nomeAtividade = nomeAtividade;
        this.temaAtividade = temaAtividade;
        this.descricaoAtividade = descricaoAtividade;
        this.dataAtividade = dataAtividade;
        this.statusDoProfessor = statusDoProfessor;
        
        this.pontuacaoAtividade = pontuacaoAtividade;
    }

    /**
     * @return the idAtividade
     */
    public Integer getIdAtividade() {
        return idAtividade;
    }

    /**
     * @param idAtividade the idAtividade to set
     */
    public void setIdAtividade(Integer idAtividade) {
        this.idAtividade = idAtividade;
    }

    /**
     * @return the idProfessor
     */
    public Integer getIdProfessor() {
        return idProfessor;
    }

    /**
     * @param idProfessor the idProfessor to set
     */
    public void setIdProfessor(Integer idProfessor) {
        this.idProfessor = idProfessor;
    }

    /**
     * @return the idTurma
     */
    public Integer getIdTurma() {
        return idTurma;
    }

    /**
     * @param idTurma the idTurma to set
     */
    public void setIdTurma(Integer idTurma) {
        this.idTurma = idTurma;
    }

    /**
     * @return the nomeAtividade
     */
    public String getNomeAtividade() {
        return nomeAtividade;
    }

    /**
     * @param nomeAtividade the nomeAtividade to set
     */
    public void setNomeAtividade(String nomeAtividade) {
        this.nomeAtividade = nomeAtividade;
    }

    /**
     * @return the temaAtividade
     */
    public String getTemaAtividade() {
        return temaAtividade;
    }

    /**
     * @param temaAtividade the temaAtividade to set
     */
    public void setTemaAtividade(String temaAtividade) {
        this.temaAtividade = temaAtividade;
    }

    /**
     * @return the descricaoAtividade
     */
    public String getDescricaoAtividade() {
        return descricaoAtividade;
    }

    /**
     * @param descricaoAtividade the descricaoAtividade to set
     */
    public void setDescricaoAtividade(String descricaoAtividade) {
        this.descricaoAtividade = descricaoAtividade;
    }

    /**
     * @return the dataAtividade
     */
    public Date getDataAtividade() {
        return dataAtividade;
    }

    /**
     * @param dataAtividade the dataAtividade to set
     */
    public void setDataAtividade(Date dataAtividade) {
        this.dataAtividade = dataAtividade;
    }

    /**
     * @return the statusDoProfessor
     */
    public String getStatusDoProfessor() {
        return statusDoProfessor;
    }

    /**
     * @param statusDoProfessor the statusDoProfessor to set
     */
    public void setStatusDoProfessor(String statusDoProfessor) {
        this.statusDoProfessor = statusDoProfessor;
    }
    
    /**
     * @return the pontuacaoAtividade
     */
    public Double getPontuacaoAtividade() {
        return pontuacaoAtividade;
    }

    /**
     * @param pontuacaoAtividade the pontuacaoAtividade to set
     */
    public void setPontuacaoAtividade(Double pontuacaoAtividade) {
        this.pontuacaoAtividade = pontuacaoAtividade;
    }

    

    
}
