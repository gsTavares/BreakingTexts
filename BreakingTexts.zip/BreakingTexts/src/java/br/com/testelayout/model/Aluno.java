/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.model;

import java.util.Date;

/**
 *
 * @author PICHAU
 */
public class Aluno extends Usuario {
    private String raAluno;
    private Integer idTurma;
    private Date dataNascAluno;
    private String statusAluno;
    
    public Aluno(){
        
    }

    public Aluno(String raAluno, Integer idTurma, Date dataNascAluno, String statusAluno, int id, String nome, String senha, String tipoUsuario) {
        super(id, nome, senha, tipoUsuario);
        this.raAluno = raAluno;
        this.idTurma = idTurma;
        this.dataNascAluno = dataNascAluno;
        this.statusAluno = statusAluno;
        
    }

    /**
     * @return the raAluno
     */
    public String getRaAluno() {
        return raAluno;
    }

    /**
     * @param raAluno the raAluno to set
     */
    public void setRaAluno(String raAluno) {
        this.raAluno = raAluno;
    }

    /**
     * @return the idTurma
     */
    public Integer getIdTurma() {
        return idTurma;
    }

    /**
     * @param idTurma the idTurma to set
     */
    public void setIdTurma(Integer idTurma) {
        this.idTurma = idTurma;
    }

    /**
     * @return the dataNascAluno
     */
    public Date getDataNascAluno() {
        return dataNascAluno;
    }

    /**
     * @param dataNascAluno the dataNascAluno to set
     */
    public void setDataNascAluno(Date dataNascAluno) {
        this.dataNascAluno = dataNascAluno;
    }

    /**
     * @return the statusAluno
     */
    public String getStatusAluno() {
        return statusAluno;
    }

    /**
     * @param statusAluno the statusAluno to set
     */
    public void setStatusAluno(String statusAluno) {
        this.statusAluno = statusAluno;
    }

    

    
    
    
    
}
