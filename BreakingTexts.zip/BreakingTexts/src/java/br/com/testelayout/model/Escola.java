/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.model;

/**
 *
 * @author PICHAU
 */
public class Escola extends Usuario{
    private String cnpjEscola;
    private String estadoEscola;
    private String cidadeEscola;

    public Escola() {
    }

    

    public Escola(String cnpjEscola, String estadoEscola, String cidadeEscola, int id, String nome, String senha, String tipoUsuario) {
        super(id, nome, senha, tipoUsuario);
        this.cnpjEscola = cnpjEscola;
        this.estadoEscola = estadoEscola;
        this.cidadeEscola = cidadeEscola;
    }

    

    /**
     * @return the cnpjEscola
     */
    public String getCnpjEscola() {
        return cnpjEscola;
    }

    /**
     * @param cnpjEscola the cnpjEscola to set
     */
    public void setCnpjEscola(String cnpjEscola) {
        this.cnpjEscola = cnpjEscola;
    }

    /**
     * @return the estadoEscola
     */
    public String getEstadoEscola() {
        return estadoEscola;
    }

    /**
     * @param estadoEscola the estadoEscola to set
     */
    public void setEstadoEscola(String estadoEscola) {
        this.estadoEscola = estadoEscola;
    }

    /**
     * @return the cidadeEscola
     */
    public String getCidadeEscola() {
        return cidadeEscola;
    }

    /**
     * @param cidadeEscola the cidadeEscola to set
     */
    public void setCidadeEscola(String cidadeEscola) {
        this.cidadeEscola = cidadeEscola;
    }

    
}
