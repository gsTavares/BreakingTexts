/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.model;

/**
 *
 * @author PICHAU
 */
public class Turma {
    private Integer idTurma;
    private Integer idEscola;
    private Integer idProfessor;
    private String nomeTurma;
    private Integer qtdAlunos;
    
    
    public Turma(){
        
    }

    public Turma(Integer idTurma, Integer idEscola, Integer idProfessor, String nomeTurma, Integer qtdAlunos, String statusTurma) {
        this.idTurma = idTurma;
        this.idEscola = idEscola;
        this.idProfessor = idProfessor;
        this.nomeTurma = nomeTurma;
        this.qtdAlunos = qtdAlunos;
    }

    /**
     * @return the idTurma
     */
    public Integer getIdTurma() {
        return idTurma;
    }

    /**
     * @param idTurma the idTurma to set
     */
    public void setIdTurma(Integer idTurma) {
        this.idTurma = idTurma;
    }

    /**
     * @return the idEscola
     */
    public Integer getIdEscola() {
        return idEscola;
    }

    /**
     * @param idEscola the idEscola to set
     */
    public void setIdEscola(Integer idEscola) {
        this.idEscola = idEscola;
    }

    /**
     * @return the idProfessor
     */
    public Integer getIdProfessor() {
        return idProfessor;
    }

    /**
     * @param idProfessor the idProfessor to set
     */
    public void setIdProfessor(Integer idProfessor) {
        this.idProfessor = idProfessor;
    }

    /**
     * @return the nomeTurma
     */
    public String getNomeTurma() {
        return nomeTurma;
    }

    /**
     * @param nomeTurma the nomeTurma to set
     */
    public void setNomeTurma(String nomeTurma) {
        this.nomeTurma = nomeTurma;
    }

    /**
     * @return the qtdAlunos
     */
    public Integer getQtdAlunos() {
        return qtdAlunos;
    }

    /**
     * @param qtdAlunos the qtdAlunos to set
     */
    public void setQtdAlunos(Integer qtdAlunos) {
        this.qtdAlunos = qtdAlunos;
    }

    /**
     * @return the statusTurma
     */
  

    
}
