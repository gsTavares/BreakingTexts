/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.model;

/**
 *
 * @author PICHAU
 */
public class ProfessorEscola {
    private int idEscola;
    private int idProfessor;
    
    public ProfessorEscola(){
        
    }

    public ProfessorEscola(int idEscola, int idProfessor) {
        this.idEscola = idEscola;
        this.idProfessor = idProfessor;
    }

    /**
     * @return the idEscola
     */
    public int getIdEscola() {
        return idEscola;
    }

    /**
     * @param idEscola the idEscola to set
     */
    public void setIdEscola(int idEscola) {
        this.idEscola = idEscola;
    }

    /**
     * @return the idProfessor
     */
    public int getIdProfessor() {
        return idProfessor;
    }

    /**
     * @param idProfessor the idProfessor to set
     */
    public void setIdProfessor(int idProfessor) {
        this.idProfessor = idProfessor;
    }
}
