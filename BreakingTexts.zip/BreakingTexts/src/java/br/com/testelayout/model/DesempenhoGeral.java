/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.model;

/**
 *
 * @author PICHAU
 */
public class DesempenhoGeral {
    private Integer idDesempenho;
    private Integer idTurma;
    private Double mediaDesempenho;
    private String nomeTurma;
    
    public DesempenhoGeral(){
        
    }

    public DesempenhoGeral(Integer idDesempenho, Integer idTurma, Double mediaDesempenho, String nomeTurma) {
        this.idDesempenho = idDesempenho;
        this.idTurma = idTurma;
        this.mediaDesempenho = mediaDesempenho;
        this.nomeTurma = nomeTurma;
    }

    /**
     * @return the idDesempenho
     */
    public Integer getIdDesempenho() {
        return idDesempenho;
    }

    /**
     * @param idDesempenho the idDesempenho to set
     */
    public void setIdDesempenho(Integer idDesempenho) {
        this.idDesempenho = idDesempenho;
    }

    /**
     * @return the idTurma
     */
    public Integer getIdTurma() {
        return idTurma;
    }

    /**
     * @param idTurma the idTurma to set
     */
    public void setIdTurma(Integer idTurma) {
        this.idTurma = idTurma;
    }

    /**
     * @return the mediaDesempenho
     */
    public Double getMediaDesempenho() {
        return mediaDesempenho;
    }

    /**
     * @param mediaDesempenho the mediaDesempenho to set
     */
    public void setMediaDesempenho(Double mediaDesempenho) {
        this.mediaDesempenho = mediaDesempenho;
    }

    /**
     * @return the nomeTurma
     */
    public String getNomeTurma() {
        return nomeTurma;
    }

    /**
     * @param nomeTurma the nomeTurma to set
     */
    public void setNomeTurma(String nomeTurma) {
        this.nomeTurma = nomeTurma;
    }

    
}
