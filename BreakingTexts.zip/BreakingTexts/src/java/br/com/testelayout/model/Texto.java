/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.model;

import java.util.Date;

/**
 *
 * @author PICHAU
 */
public class Texto {
    private Integer idTexto;
    private Integer idAluno;
    private Integer idAtividade;
    private String tituloTexto;
    private String caminhoArquivoTexto;
    private Double pontuacaoTexto;
    private Date dataEnvioTexto;
    private String comentarioTexto;
    private String statusCorrecao;
    
    public Texto(){
        
    }

    public Texto(Integer idTexto, Integer idAluno, Integer idAtividade, String tituloTexto, String caminhoArquivoTexto, Double pontuacaoTexto, String comentarioTexto, Date dataEnvioTexto, String statusCorrecao) {
        this.idTexto = idTexto;
        this.idAluno = idAluno;
        this.idAtividade = idAtividade;
        this.tituloTexto = tituloTexto;
        this.caminhoArquivoTexto = caminhoArquivoTexto;
        this.pontuacaoTexto = pontuacaoTexto;
        this.dataEnvioTexto = dataEnvioTexto;
        this.comentarioTexto = comentarioTexto;
        this.statusCorrecao = statusCorrecao;
    }

    /**
     * @return the idTexto
     */
    public Integer getIdTexto() {
        return idTexto;
    }

    /**
     * @param idTexto the idTexto to set
     */
    public void setIdTexto(Integer idTexto) {
        this.idTexto = idTexto;
    }

    /**
     * @return the idAluno
     */
    public Integer getIdAluno() {
        return idAluno;
    }

    /**
     * @param idAluno the idAluno to set
     */
    public void setIdAluno(Integer idAluno) {
        this.idAluno = idAluno;
    }

    /**
     * @return the idAtividade
     */
    public Integer getIdAtividade() {
        return idAtividade;
    }

    /**
     * @param idAtividade the idAtividade to set
     */
    public void setIdAtividade(Integer idAtividade) {
        this.idAtividade = idAtividade;
    }

    /**
     * @return the tituloTexto
     */
    public String getTituloTexto() {
        return tituloTexto;
    }

    /**
     * @param tituloTexto the tituloTexto to set
     */
    public void setTituloTexto(String tituloTexto) {
        this.tituloTexto = tituloTexto;
    }

    /**
     * @return the caminhoArquivoTexto
     */
    public String getCaminhoArquivoTexto() {
        return caminhoArquivoTexto;
    }

    /**
     * @param caminhoArquivoTexto the caminhoArquivoTexto to set
     */
    public void setCaminhoArquivoTexto(String caminhoArquivoTexto) {
        this.caminhoArquivoTexto = caminhoArquivoTexto;
    }

    /**
     * @return the pontuacaoTexto
     */
    public Double getPontuacaoTexto() {
        return pontuacaoTexto;
    }

    /**
     * @param pontuacaoTexto the pontuacaoTexto to set
     */
    public void setPontuacaoTexto(Double pontuacaoTexto) {
        this.pontuacaoTexto = pontuacaoTexto;
    }

    /**
     * @return the dataEnvioTexto
     */
    public Date getDataEnvioTexto() {
        return dataEnvioTexto;
    }

    /**
     * @param dataEnvioTexto the dataEnvioTexto to set
     */
    public void setDataEnvioTexto(Date dataEnvioTexto) {
        this.dataEnvioTexto = dataEnvioTexto;
    }

    /**
     * @return the comentarioTexto
     */
    public String getComentarioTexto() {
        return comentarioTexto;
    }

    /**
     * @param comentarioTexto the comentarioTexto to set
     */
    public void setComentarioTexto(String comentarioTexto) {
        this.comentarioTexto = comentarioTexto;
    }

    /**
     * @return the statusCorrecao
     */
    public String getStatusCorrecao() {
        return statusCorrecao;
    }

    /**
     * @param statusCorrecao the statusCorrecao to set
     */
    public void setStatusCorrecao(String statusCorrecao) {
        this.statusCorrecao = statusCorrecao;
    }

    

    
    
    
}
