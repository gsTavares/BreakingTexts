/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.model;

/**
 *
 * @author PICHAU
 */
public class Material {
    private Integer idMaterial;
    private Integer idProfessor;
    private Integer idTurma;
    
    private String tituloMaterial;
    private String tipoMaterial;
    private String caminhoMaterial;

    public Material() {
    }

    public Material(Integer idMaterial, Integer idProfessor, Integer idTurma, String tituloMaterial, String tipoMaterial, String caminhoMaterial) {
        this.idMaterial = idMaterial;
        this.idProfessor = idProfessor;
        this.idTurma = idTurma;
        this.tituloMaterial = tituloMaterial;
        this.tipoMaterial = tipoMaterial;
        this.caminhoMaterial = caminhoMaterial;
    }

    /**
     * @return the idMaterial
     */
    public Integer getIdMaterial() {
        return idMaterial;
    }

    /**
     * @param idMaterial the idMaterial to set
     */
    public void setIdMaterial(Integer idMaterial) {
        this.idMaterial = idMaterial;
    }

    /**
     * @return the idProfessor
     */
    public Integer getIdProfessor() {
        return idProfessor;
    }

    /**
     * @param idProfessor the idProfessor to set
     */
    public void setIdProfessor(Integer idProfessor) {
        this.idProfessor = idProfessor;
    }

    /**
     * @return the idTurma
     */
    public Integer getIdTurma() {
        return idTurma;
    }

    /**
     * @param idTurma the idTurma to set
     */
    public void setIdTurma(Integer idTurma) {
        this.idTurma = idTurma;
    }

    /**
     * @return the tituloMaterial
     */
    public String getTituloMaterial() {
        return tituloMaterial;
    }

    /**
     * @param tituloMaterial the tituloMaterial to set
     */
    public void setTituloMaterial(String tituloMaterial) {
        this.tituloMaterial = tituloMaterial;
    }

    /**
     * @return the tipoMaterial
     */
    public String getTipoMaterial() {
        return tipoMaterial;
    }

    /**
     * @param tipoMaterial the tipoMaterial to set
     */
    public void setTipoMaterial(String tipoMaterial) {
        this.tipoMaterial = tipoMaterial;
    }

    /**
     * @return the caminhoMaterial
     */
    public String getCaminhoMaterial() {
        return caminhoMaterial;
    }

    /**
     * @param caminhoMaterial the caminhoMaterial to set
     */
    public void setCaminhoMaterial(String caminhoMaterial) {
        this.caminhoMaterial = caminhoMaterial;
    }
    
    
    
    
    
}
