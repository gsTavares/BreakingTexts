/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.model;

/**
 *
 * @author PICHAU
 */
public class Professor extends Usuario {
    private int idadeProfessor;
    private String cpfProfessor;
    private String statusProfessor;
    
    public Professor(){
        
    }

    public Professor(int idadeProfessor, String cpfProfessor, String statusProfessor, int id, String nome, String senha, String tipoUsuario) {
        super(id, nome, senha, tipoUsuario);
        this.idadeProfessor = idadeProfessor;
        this.cpfProfessor = cpfProfessor;
    }

    /**
     * @return the idadeProfessor
     */
    public int getIdadeProfessor() {
        return idadeProfessor;
    }

    /**
     * @param idadeProfessor the idadeProfessor to set
     */
    public void setIdadeProfessor(int idadeProfessor) {
        this.idadeProfessor = idadeProfessor;
    }

    /**
     * @return the cpfProfessor
     */
    public String getCpfProfessor() {
        return cpfProfessor;
    }

    /**
     * @param cpfProfessor the cpfProfessor to set
     */
    public void setCpfProfessor(String cpfProfessor) {
        this.cpfProfessor = cpfProfessor;
    }

    /**
     * @return the statusProfessor
     */
    public String getStatusProfessor() {
        return statusProfessor;
    }

    /**
     * @param statusProfessor the statusProfessor to set
     */
    public void setStatusProfessor(String statusProfessor) {
        this.statusProfessor = statusProfessor;
    }
    
    

    
}
