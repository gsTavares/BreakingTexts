/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.controller;

import br.com.testelayout.dao.ProfessorEscolaDAOImpl;
import br.com.testelayout.dao.TextoDAOImpl;
import br.com.testelayout.dao.TurmaDAOImpl;
import br.com.testelayout.dao.UsuarioDAO;
import br.com.testelayout.model.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.jboss.weld.servlet.SessionHolder;

/**
 *
 * @author PICHAU
 */
@WebServlet(name = "Login", urlPatterns = {"/Login"})
public class Login extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String mensagem = "";
        //sessionScope.usuario.nome
        if (request.getParameter("acao").equals("Entrar")) {
            String nomeUsuario = request.getParameter("nomeUsuario");
            String senhaUsuario = request.getParameter("senhaUsuario");
            if (!nomeUsuario.equals("") && !senhaUsuario.equals("")) {
                try {
                    UsuarioDAO dao = new UsuarioDAO();
                    Usuario usuario = dao.validarLogin(nomeUsuario, senhaUsuario);

                    if (usuario != null) {
                        HttpSession session = request.getSession(true);
                        session.setAttribute("usuario", usuario);
                        mensagem = "Olá " + usuario.getNome() + "!";
                        
                        
                        session.setAttribute("msg3", mensagem);

                        String tipoUsuario = usuario.getTipoUsuario();
                        
                        if (tipoUsuario.equals("E")) {
                            request.getRequestDispatcher("escola/indexEscola.jsp").forward(request, response);
                        } else if (tipoUsuario.equals("P")) {
                            ProfessorEscolaDAOImpl daoPE = new ProfessorEscolaDAOImpl();
                            
                            request.setAttribute("escolas", daoPE.listarEscolas(usuario.getId()));
                            request.getRequestDispatcher("professor/indexProfessor.jsp").forward(request, response);
                        } else {
                            
                            
                            TextoDAOImpl daoTxt = new TextoDAOImpl();
                            TurmaDAOImpl daoT = new TurmaDAOImpl();
                            
                            request.setAttribute("topTextos", daoTxt.listarMelhoresTextos(usuario.getId()));
                            request.setAttribute("idTurma", daoT.recuperarIdTurma(usuario.getId()));
                            
                            request.getRequestDispatcher("aluno/indexAluno.jsp").forward(request, response);
                        }
                    } else {
                        mensagem = "Nome de usuario ou senha inválidos, tente novamente";
                        request.setAttribute("msg4", mensagem);
                        request.getRequestDispatcher("index.jsp").forward(request, response);
                    }
                } catch (Exception e) {
                    System.out.println("Problemas ao logar \n Erro: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        } else if (request.getParameter("acao").equals("Encerrar")) {
            HttpSession session = request.getSession(true);
            session.invalidate();
            response.sendRedirect("index.jsp");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
