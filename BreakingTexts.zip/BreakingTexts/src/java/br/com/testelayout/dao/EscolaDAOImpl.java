/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.dao;

import br.com.testelayout.model.Escola;
import br.com.testelayout.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

/**
 *
 * @author PICHAU
 */
public class EscolaDAOImpl implements GenericDAO {
    
    private Connection conn;
    public EscolaDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.abrirconexao();
            System.out.println("Conectado com sucesso!");
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Override
    public boolean cadastrar(Object object) {
        Escola oEscola = (Escola)object;
        
        PreparedStatement stmt = null;
        
        
        String sql = "insert into escola(nomeescola,cnpjescola,estadoescola,cidadeescola,idusuario)values(?,?,?,?,?)";
        
        try {
            stmt = this.conn.prepareStatement(sql);
            
            stmt.setString(1, oEscola.getNome());
            stmt.setString(2, oEscola.getCnpjEscola());
            stmt.setString(3, oEscola.getEstadoEscola());
            stmt.setString(4, oEscola.getCidadeEscola());
            try {
                stmt.setInt(5, new UsuarioDAO().cadastrar(oEscola));
            } catch (Exception e) {
                System.out.println("Erro ao cadastrar usuário! \n Erro: "+e.getMessage());
                e.printStackTrace();
            }
            stmt.execute();
            return true;
            
        } catch (Exception e) {
            System.out.println("Erro ao cadastrar escola \n Erro: "+e.getMessage());
            e.printStackTrace();
            
            return false;
        } finally{
            try {
                ConnectionFactory.fechar(conn, stmt);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: "+e.getMessage());
                e.printStackTrace();
            }
        } 
        
    }
    
    public Integer recuperarIdEscola(String nomeEscola){
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Integer idEscola = 0;
        
        String sql = "select idescola from escola where nomeescola = '"+nomeEscola+"'";
        
        try {
            stmt = this.conn.prepareStatement(sql);
            
            rs = stmt.executeQuery();
            if(rs.next()){
                idEscola = rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println("Erro ao recuperar o id \n Erro: "+e.getMessage());
            e.printStackTrace();
        }finally{
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: "+e.getMessage());
                e.printStackTrace();
            }
        }
        
        return idEscola;
    }
    

    @Override
    public List<Object> listar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void excluir(int idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean alterar(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
