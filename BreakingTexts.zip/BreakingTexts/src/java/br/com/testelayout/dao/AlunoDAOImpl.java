/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.dao;

import br.com.testelayout.model.Aluno;
import br.com.testelayout.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PICHAU
 */
public class AlunoDAOImpl implements GenericDAO {
    private Connection conn;
    
    public AlunoDAOImpl()throws Exception{
        try {
            this.conn = ConnectionFactory.abrirconexao();
            System.out.println("Conectado com sucesso!");
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Override
    public boolean cadastrar(Object object) {
        Aluno oAluno = (Aluno)object;
        
        PreparedStatement stmt = null;
        String sql = "insert into aluno(raaluno, idturma, nomealuno, idusuario, datanascaluno, statusaluno)values(?,?,?,?,?,?)";
        
        try {
            stmt = this.conn.prepareStatement(sql);
            
            stmt.setString(1, oAluno.getRaAluno());
            stmt.setInt(2, oAluno.getIdTurma());
            stmt.setString(3, oAluno.getNome());
            
            try {
                stmt.setInt(4, new UsuarioDAO().cadastrar(oAluno));
            } catch (Exception e) {
                System.out.println("Erro ao cadastrar usuário - Aluno \n Erro: "+e.getMessage());
                e.printStackTrace();
            }
            
            stmt.setDate(5, new java.sql.Date(oAluno.getDataNascAluno().getTime()));
            stmt.setString(6, oAluno.getStatusAluno());
            
            stmt.execute();
        } catch (Exception e) {
            System.out.println("Erro ao cadastrar aluno \n Erro: "+e.getMessage());
            e.printStackTrace();
            
            return false;
        }finally{
            try {
                ConnectionFactory.fechar(conn, stmt);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: "+e.getMessage());
                e.printStackTrace();
            }
        }
        
        return true;
    }
    
    public List<Object> listarAlunos(Integer idTurma){
        
        List<Object> resultado = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        String sql = "select * from aluno where idturma = ? order by nomealuno";
        
        try {
            stmt = this.conn.prepareStatement(sql);
            
            stmt.setInt(1, idTurma);
            
            rs = stmt.executeQuery();
            while(rs.next()){
                Aluno oAluno = new Aluno();
                
                oAluno.setId(rs.getInt("idaluno"));
                oAluno.setIdTurma(rs.getInt("idturma"));
                oAluno.setNome(rs.getString("nomealuno"));
                oAluno.setDataNascAluno(rs.getDate("datanascaluno"));
                oAluno.setRaAluno(rs.getString("raaluno"));
                oAluno.setStatusAluno(rs.getString("statusaluno"));
                
                resultado.add(oAluno);
            }
        } catch (Exception e) {
            System.out.println("Erro ao listar aluno \n Erro: "+ e.getMessage());
            e.printStackTrace();
        }
        
        return resultado;
    }

    @Override
    public List<Object> listar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void excluir(int idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int idObject) {
        Aluno aluno = new Aluno();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        String sql = "select * from aluno where idaluno=?";
        
        try {
            stmt = this.conn.prepareStatement(sql);
            
            stmt.setInt(1, idObject);
            rs = stmt.executeQuery();
            
            if(rs.next()){
                aluno = new Aluno();
                
                aluno.setNome(rs.getString("nomealuno"));
                aluno.setDataNascAluno(rs.getDate("datanascaluno"));
                aluno.setRaAluno(rs.getString("raaluno"));
                aluno.setId(rs.getInt("idusuario"));
                aluno.setIdTurma(rs.getInt("idturma"));
                aluno.setStatusAluno(rs.getString("statusaluno"));
            }
        } catch (Exception e) {
            System.out.println("Erro ao carregar aluno \n Erro: "+e.getMessage());
            e.printStackTrace();
            return false;
            
        }finally{
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: "+e.getMessage());
                e.printStackTrace();
            }
        }
        return aluno;
    }

    @Override
    public Boolean alterar(Object object) {
        Aluno aluno = (Aluno) object;
        
        PreparedStatement stmt = null;
        String sql = "update aluno set raaluno=?, datanascaluno=?, nomealuno=?, statusaluno=? where idusuario=?";
        
        try {
            stmt = this.conn.prepareStatement(sql);
            
            stmt.setString(1, aluno.getRaAluno());
            stmt.setDate(2, new java.sql.Date(aluno.getDataNascAluno().getTime()));
            stmt.setString(3, aluno.getNome());
            stmt.setString(4, aluno.getStatusAluno());
            stmt.setInt(5, aluno.getId());
            
            try {
                if(new UsuarioDAO().alterarUsuario(aluno)){
                    
                    stmt.executeUpdate();
                    return true;
                }else{
                    return false;
                }
            } catch (Exception e) {
                System.out.println("Erro ao alterar usuário \n Erro: "+e.getMessage());
                e.printStackTrace();
                
                return false;
            }
        } catch (Exception e) {
            System.out.println("Erro ao alterar aluno \n Erro: "+e.getMessage());
            e.printStackTrace();
            
            return false;
        } finally{
            try {
                ConnectionFactory.fechar(conn, stmt);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: "+e.getMessage());
                e.printStackTrace();
            }
        }
    }
    
}
