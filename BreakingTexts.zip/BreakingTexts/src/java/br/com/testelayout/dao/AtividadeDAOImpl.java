/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.dao;

import br.com.testelayout.model.Atividade;
import br.com.testelayout.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PICHAU
 */
public class AtividadeDAOImpl implements GenericDAO {

    private Connection conn;

    public AtividadeDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.abrirconexao();
            System.out.println("Conectado com sucesso!");
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    public List<Object> listarAtividadesProfessor(Integer idUsuarioProfessor, Integer idTurma) {
        List<Object> resultado = new ArrayList<>();

        Atividade oAtividade = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select a.* from professor p, atividade a, turma t where p.idusuario=? and a.idturma =? and a.idprofessor = p.idprofessor and t.idturma = a.idturma";

        try {
            stmt = this.conn.prepareStatement(sql);

            stmt.setInt(1, idUsuarioProfessor);
            stmt.setInt(2, idTurma);

            rs = stmt.executeQuery();
            while (rs.next()) {
                oAtividade = new Atividade();

                oAtividade.setIdAtividade(rs.getInt("idatividade"));
                oAtividade.setIdTurma(rs.getInt("idturma"));
                oAtividade.setNomeAtividade(rs.getString("nomeatividade"));
                oAtividade.setTemaAtividade(rs.getString("temaatividade"));
                oAtividade.setDescricaoAtividade(rs.getString("descricaoatividade"));
                oAtividade.setDataAtividade(rs.getDate("dataatividade"));
                oAtividade.setStatusDoProfessor(rs.getString("statusdoprofessor"));

                resultado.add(oAtividade);
            }

        } catch (Exception e) {
            System.out.println("Erro ao listar atividades \n Erro: " + e.getMessage());
            e.printStackTrace();

        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return resultado;
    }

    @Override
    public boolean cadastrar(Object object) {
        Atividade oAtividade = (Atividade) object;
        Integer idProfessor = null;

        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sqlP = "select idprofessor from professor where idusuario = ?";
        String sql = "insert into atividade (idprofessor, idturma, nomeatividade, temaatividade, descricaoatividade, dataatividade, statusdoprofessor)values(?,?,?,?,?,?,?)";

        try {
            stmt = this.conn.prepareStatement(sqlP);

            stmt.setInt(1, oAtividade.getIdProfessor());
            rs = stmt.executeQuery();

            if (rs.next()) {
                idProfessor = rs.getInt("idprofessor");

                stmt = this.conn.prepareStatement(sql);

                stmt.setInt(1, idProfessor);
                stmt.setInt(2, oAtividade.getIdTurma());
                stmt.setString(3, oAtividade.getNomeAtividade());
                stmt.setString(4, oAtividade.getTemaAtividade());
                stmt.setString(5, oAtividade.getDescricaoAtividade());
                stmt.setDate(6, new java.sql.Date(oAtividade.getDataAtividade().getTime()));
                stmt.setString(7, oAtividade.getStatusDoProfessor());

                stmt.execute();
            }

        } catch (Exception e) {
            System.out.println("Erro ao cadastrar atividade \n Erro:" + e.getMessage());
            e.printStackTrace();

            return false;
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return true;
    }

    public List<Object> listarAtividadesAluno(Integer idUsuarioAluno) {
        List<Object> resultado = new ArrayList<>();

        Atividade oAtividade = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select a.* from aluno al, atividade a where al.idusuario=? and a.idturma = al.idturma and a.statusdoprofessor = 'Em andamento'";

        try {
            stmt = this.conn.prepareStatement(sql);

            stmt.setInt(1, idUsuarioAluno);

            rs = stmt.executeQuery();
            while (rs.next()) {
                oAtividade = new Atividade();

                oAtividade.setIdAtividade(rs.getInt("idatividade"));
                oAtividade.setIdTurma(rs.getInt("idturma"));
                oAtividade.setNomeAtividade(rs.getString("nomeatividade"));
                oAtividade.setTemaAtividade(rs.getString("temaatividade"));
                oAtividade.setDescricaoAtividade(rs.getString("descricaoatividade"));
                oAtividade.setDataAtividade(rs.getDate("dataatividade"));

                resultado.add(oAtividade);
            }

        } catch (Exception e) {
            System.out.println("Erro ao listar atividades \n Erro: " + e.getMessage());
            e.printStackTrace();

        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return resultado;
    }

    @Override
    public List<Object> listar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void excluir(int idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int idObject) {
        Atividade atividade = new Atividade();

        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select idatividade, temaatividade, descricaoatividade from atividade where idatividade=?";

        try {
            stmt = this.conn.prepareStatement(sql);

            stmt.setInt(1, idObject);
            rs = stmt.executeQuery();

            if (rs.next()) {
                atividade = new Atividade();

                atividade.setIdAtividade(rs.getInt("idatividade"));
                atividade.setTemaAtividade(rs.getString("temaatividade"));
                atividade.setDescricaoAtividade(rs.getString("descricaoatividade"));

            }
        } catch (Exception e) {
            System.out.println("Erro ao carregar atividade \n Erro: " + e.getMessage());
            e.printStackTrace();
            return false;

        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return atividade;
    }

    @Override
    public Boolean alterar(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Boolean finalizarAtividade(Object object) {
        Atividade atividade = (Atividade) object;

        PreparedStatement stmt = null;

        String sql = "update atividade set statusdoprofessor=?, pontuacaoatividade=? where idatividade =?";

        try {
            stmt = this.conn.prepareStatement(sql);

            stmt.setString(1, atividade.getStatusDoProfessor());
            stmt.setDouble(2, atividade.getPontuacaoAtividade());
            stmt.setInt(3, atividade.getIdAtividade());
            
            stmt.executeUpdate();
            
            
        } catch (Exception e) {
            System.out.println("Erro ao finalizar atividade \n Erro: "+e.getMessage());
            e.printStackTrace();
            return false;
        }
        
        return true;
    }
    
    public Double mediaAtividadesTurma(Integer idTurma){
        
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        Double somaPont = 0.0;
        Double dsGeral = null;
        Double pont;
        
        int i = 0;
        
        String sql = "select pontuacaoatividade from atividade where idturma =?";
        
        try {
            stmt = this.conn.prepareStatement(sql);
            
            stmt.setInt(1, idTurma);
            
            rs = stmt.executeQuery();
            while(rs.next()){
                pont = rs.getDouble("pontuacaoatividade");
                somaPont = somaPont + pont;
                
                i++;
            }
            
            dsGeral = somaPont/i;
            
        } catch (Exception e) {
            System.out.println("Erro ao calcular desempenho geral \n Erro: "+e.getMessage());
            e.printStackTrace();
            
        }finally{
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: "+e.getMessage());
                e.printStackTrace();
            }
        }
        
        return dsGeral;
    }
}
