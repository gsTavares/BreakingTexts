/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.dao;

import br.com.testelayout.model.Escola;
import br.com.testelayout.model.Usuario;
import br.com.testelayout.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

/**
 *
 * @author PICHAU
 */
public class UsuarioDAO {

    private Connection conn;

    public UsuarioDAO() throws Exception {
        try {
            this.conn = ConnectionFactory.abrirconexao();
            System.out.println("Conectado com sucesso!");
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    public Integer cadastrar(Usuario usuario) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Integer idUsuario = null;
        String sql = "insert into usuario(nomeusuario,senhausuario,tipousuario)values(?,?,?)returning(idusuario)";

        try {
            stmt = this.conn.prepareStatement(sql);

            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getSenha());
            stmt.setString(3, usuario.getTipoUsuario());

            rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuario = rs.getInt("idusuario");
            }
        } catch (Exception e) {
            System.out.println("Erro ao cadastrar usuario \n Erro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão com o banco \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return idUsuario;
    }

    public Usuario validarLogin(String nomeusuario, String senhausuario) {

        PreparedStatement stmt = null;
        ResultSet rs = null;
        Usuario usuario = null;

        String sql = "select * from usuario where nomeusuario = ? and senhausuario = ?";

        try {
            stmt = this.conn.prepareStatement(sql);

            stmt.setString(1, nomeusuario);
            stmt.setString(2, senhausuario);

            rs = stmt.executeQuery();

            if (rs.next()) {
                usuario = new Usuario();
                usuario.setId(rs.getInt("idusuario"));
                usuario.setNome(rs.getString("nomeusuario"));
                usuario.setSenha(rs.getString("senhausuario"));
                usuario.setTipoUsuario(rs.getString("tipousuario"));
            }
        } catch (Exception e) {
            System.out.println("Erro ao logar usuario \n Erro " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão com o banco \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return usuario;
    }
    
    public boolean alterarUsuario(Object object){
        Usuario usuario = (Usuario) object;
        
        PreparedStatement stmt = null;
        String sql = "update usuario set nomeusuario=?, senhausuario=? where idusuario=?";
        
        try {
            stmt = this.conn.prepareStatement(sql);
            
            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getSenha());
            stmt.setInt(3, usuario.getId());
            
            stmt.executeUpdate();
            
            return true;
        } catch (Exception e) {
            System.out.println("Erro ao alterar usuário \n Erro: "+e.getMessage());
            e.printStackTrace();
            
            return false;
        }finally{
            try {
                ConnectionFactory.fechar(conn, stmt);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: "+e.getMessage());
                e.printStackTrace();
            }
        }
        
        
    }
}
