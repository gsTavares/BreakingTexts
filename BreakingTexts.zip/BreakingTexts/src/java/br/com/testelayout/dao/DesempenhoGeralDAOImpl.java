/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.dao;

import br.com.testelayout.model.DesempenhoGeral;
import br.com.testelayout.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PICHAU
 */
public class DesempenhoGeralDAOImpl {
    private Connection conn;

    public DesempenhoGeralDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.abrirconexao();
            System.out.println("Conectado com sucesso!");
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }
    
    public Boolean salvarDesempenho( Object object){
        DesempenhoGeral dsG = (DesempenhoGeral) object;
        
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        String sqlVerificar = "select idturma from desempenho where idturma =?";
        String sqlAtualizar = "update desempenho set mediadesempenho =? where idturma =?";
        String sqlSalvar = "insert into desempenho(idturma, mediadesempenho, nometurma)values(?,?,?)";
        
        try {
            stmt = this.conn.prepareStatement(sqlVerificar);
            
            stmt.setInt(1, dsG.getIdTurma());
            rs = stmt.executeQuery();
            if(rs.next()){
                stmt = this.conn.prepareStatement(sqlAtualizar);
                
                stmt.setDouble(1, dsG.getMediaDesempenho());
                stmt.setInt(2, dsG.getIdTurma());
                
                stmt.executeUpdate();
            }else{
                stmt = this.conn.prepareStatement(sqlSalvar);
                
                stmt.setInt(1, dsG.getIdTurma());
                stmt.setDouble(2, dsG.getMediaDesempenho());
                stmt.setString(3, dsG.getNomeTurma());
                stmt.execute();
            }
            
        } catch (Exception e) {
            System.out.println("Erro ao salvar desempenho geral \n Erro: "+e.getMessage());
            e.printStackTrace();
            
            return false;
        }finally{
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexao \n Erro: "+e.getMessage());
                e.printStackTrace();
            }
        }
        
        return true;
        
    }
    
    public List<Object> listarDesempenhoTurmas(Integer idUsuarioEscola){
        
        DesempenhoGeral desempenhoG = null;
        List<Object> resultado = new ArrayList<>();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        Integer idEscola = null;
        
        String sqlidEscola = "select idescola from escola where idusuario = ?";
        String sqlDesempenho = "select d.* from desempenho d, turma t, escola e where d.idturma = t.idturma and t.idescola = e.idescola and e.idescola = ?";
        
        try {
            stmt = this.conn.prepareStatement(sqlidEscola);
            
            stmt.setInt(1, idUsuarioEscola);
            rs = stmt.executeQuery();
            if(rs.next()){
                idEscola = rs.getInt("idescola");
                
                stmt = this.conn.prepareStatement(sqlDesempenho);
                
                stmt.setInt(1, idEscola);
                
                rs = stmt.executeQuery();
                
                while(rs.next()){
                    desempenhoG = new DesempenhoGeral();
                    
                    desempenhoG.setIdDesempenho(rs.getInt("iddesempenho"));
                    desempenhoG.setIdTurma(rs.getInt("idturma"));
                    desempenhoG.setMediaDesempenho(rs.getDouble("mediadesempenho"));
                    desempenhoG.setNomeTurma(rs.getString("nometurma"));
                    
                    resultado.add(desempenhoG);
                }
            }
            
        } catch (Exception e) {
            System.out.println("Erro ao listar desempenho geral \n Erro: "+e.getMessage());
            e.printStackTrace();
        }finally{
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro :"+e.getMessage());
                e.printStackTrace();
            }
        }
        
        return resultado;
    }
}
