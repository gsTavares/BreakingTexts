/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.dao;

import java.util.List;

/**
 *
 * @author PICHAU
 */
public interface GenericDAO {
    
public boolean cadastrar(Object object);

//Consulta informações do BD, sem passagem de parâmetros
public List <Object> listar();

//Deleta apenas 1 registro do BD de acordo com o ID
public void excluir(int idObject);

//Utiliza-do para selecionar dados específicos de um 
public Object carregar(int idObject);

//Realiza Update
public Boolean alterar(Object object);
    
}
