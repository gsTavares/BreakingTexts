/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.dao;

import br.com.testelayout.model.Material;
import br.com.testelayout.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PICHAU
 */
public class MaterialDAOImpl implements GenericDAO{
    
    private Connection conn;
    
    public MaterialDAOImpl()throws Exception{
        try {
            this.conn = ConnectionFactory.abrirconexao();
            System.out.println("Conectado com sucesso!");
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Override
    public boolean cadastrar(Object object) {
        Material material = (Material)object;
        Integer idProfessor = null;
        
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        String sqlP = "select idprofessor from professor where idusuario =?";
        String sql = "insert into material (idprofessor, idturma, titulomaterial, tipomaterial, caminhomaterial)values(?,?,?,?,?)";
        
        try {
            stmt = this.conn.prepareStatement(sqlP);
            
            stmt.setInt(1, material.getIdProfessor());
            rs = stmt.executeQuery();
            if(rs.next()){
                idProfessor = rs.getInt("idprofessor");
                
                stmt = this.conn.prepareStatement(sql);
                
                stmt.setInt(1, idProfessor);
                stmt.setInt(2, material.getIdTurma());
                stmt.setString(3, material.getTituloMaterial());
                stmt.setString(4, material.getTipoMaterial());
                stmt.setString(5, material.getCaminhoMaterial());
                
                stmt.execute();
            }
            
        } catch (Exception e) {
            System.out.println("Erro ao cadastrar material \n Erro: "+e.getMessage());
            e.printStackTrace();
            
            return false;
        }finally{
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro"+e.getMessage());
                e.printStackTrace();
            }
        }
        return true;
    }
    
    public List<Object> listarMaterial (Integer idTurma){
        List<Object> resultado = new ArrayList<>();

        Material oMaterial = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select * from material where idturma = ? order by tipomaterial";
        
        try {
            stmt = this.conn.prepareStatement(sql);
            
            stmt.setInt(1, idTurma);
            
            rs = stmt.executeQuery();
            while(rs.next()){
                
                oMaterial = new Material();
                
                oMaterial.setIdMaterial(rs.getInt("idmaterial"));
                oMaterial.setIdProfessor(rs.getInt("idprofessor"));
                oMaterial.setIdTurma(rs.getInt("idturma"));
                oMaterial.setTituloMaterial(rs.getString("titulomaterial"));
                oMaterial.setTipoMaterial(rs.getString("tipomaterial"));
                oMaterial.setCaminhoMaterial(rs.getString("caminhomaterial"));
                
                resultado.add(oMaterial);
            }
            
        } catch (Exception e) {
            System.out.println("Erro ao listar materiais \n Erro: "+e.getMessage());
            e.printStackTrace();
        }finally{
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: "+e.getMessage());
                e.printStackTrace();
            }
        }
        
        return resultado;
    }
    
    @Override
    public List<Object> listar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void excluir(int idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean alterar(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
