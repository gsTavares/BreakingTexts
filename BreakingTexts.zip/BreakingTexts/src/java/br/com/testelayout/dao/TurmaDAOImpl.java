/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.dao;

import br.com.testelayout.model.Turma;
import br.com.testelayout.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PICHAU
 */
public class TurmaDAOImpl implements GenericDAO {

    private Connection conn;

    public TurmaDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.abrirconexao();
            System.out.println("Conectado com sucesso!");
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Override
    public boolean cadastrar(Object object) {
        Turma oTurma = (Turma) object;
        PreparedStatement stmt = null;

        String sql = "insert into turma(idprofessor, idescola, nometurma, quantidadealunosturma)values(?,?,?,?)";

        try {
            stmt = this.conn.prepareStatement(sql);

            stmt.setInt(1, oTurma.getIdProfessor());
            stmt.setInt(2, oTurma.getIdEscola());
            stmt.setString(3, oTurma.getNomeTurma());
            stmt.setInt(4, oTurma.getQtdAlunos());

            stmt.execute();

            return true;

        } catch (Exception e) {
            System.out.println("Erro ao cadastrar turma \n Erro: " + e.getMessage());
            e.printStackTrace();

            return false;
        }
    }

    public List<Object> listarTurmaEscola(Integer idEscola) {

        Turma oTurma = null;
        List<Object> resultado = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select t.* from turma t, usuario u, escola e, professor p where t.idescola = e.idescola and u.idusuario = e.idusuario and u.idusuario = ? and t.idprofessor = p.idprofessor order by idturma";

        try {
            stmt = this.conn.prepareStatement(sql);

            stmt.setInt(1, idEscola);

            rs = stmt.executeQuery();
            while (rs.next()) {
                oTurma = new Turma();
                
                oTurma.setIdTurma(rs.getInt("idturma"));
                oTurma.setIdProfessor(rs.getInt("idprofessor"));
                oTurma.setIdEscola(rs.getInt("idescola"));
                oTurma.setNomeTurma(rs.getString("nometurma"));
                oTurma.setQtdAlunos(rs.getInt("quantidadealunosturma"));

                resultado.add(oTurma);

            }
        } catch (Exception e) {
            System.out.println("Erro ao listar turmas \n Erro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }

            return resultado;
        }
    }

    public List<Object> listarTurmaProfessor(Integer idUsuarioProfessor, Integer idUsuarioEscola) {

        Turma oTurma = null;
        List<Object> resultado = new ArrayList<>();
        Integer idProfessor = null;
        Integer idEscola = null;
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql1 = "select idprofessor from professor where idusuario=?";
        String sql2 = "select idescola from escola where idusuario=?";
        String sql3 = "select * from turma where idprofessor=? and idescola =? order by idescola";

        try {
            stmt = this.conn.prepareStatement(sql1);

            stmt.setInt(1, idUsuarioProfessor);
         
            rs = stmt.executeQuery();

            if (rs.next()) {

                idProfessor = rs.getInt("idprofessor");
                stmt = this.conn.prepareStatement(sql2);

                stmt.setInt(1, idUsuarioEscola);

                rs = stmt.executeQuery();

                if (rs.next()) {
                  idEscola = rs.getInt("idescola");
                  stmt = this.conn.prepareStatement(sql3);
                  
                  stmt.setInt(1, idProfessor);
                  stmt.setInt(2, idEscola);
                  
                  rs = stmt.executeQuery();
                  while(rs.next()){
                      oTurma = new Turma();

                    oTurma.setIdTurma(rs.getInt("idturma"));
                    oTurma.setIdProfessor(rs.getInt("idprofessor"));
                    oTurma.setIdEscola(rs.getInt("idescola"));
                    oTurma.setNomeTurma(rs.getString("nometurma"));
                    oTurma.setQtdAlunos(rs.getInt("quantidadealunosturma"));

                    resultado.add(oTurma);
                  }
                }

            }
        } catch (Exception e) {
            System.out.println("Erro ao listar turmas \n Erro: "+e.getMessage());
            e.printStackTrace();
        }finally{
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: "+e.getMessage());
                e.printStackTrace();
            }
        }
        
        return resultado;
    }

    @Override
    public List<Object> listar() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void excluir(int idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int idObject) {
        Turma turma = null;

        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select * from turma where idturma = ?";
        try {
            stmt = this.conn.prepareStatement(sql);

            stmt.setInt(1, idObject);
            rs = stmt.executeQuery();

            if (rs.next()) {
                turma = new Turma();

                turma.setIdTurma(rs.getInt("idturma"));
                turma.setNomeTurma(rs.getString("nometurma"));
                turma.setIdProfessor(rs.getInt("idprofessor"));
                turma.setQtdAlunos(rs.getInt("quantidadealunosturma"));
            }
        } catch (Exception e) {
            System.out.println("Erro ao carregar turma \n Erro: " + e.getMessage());
            e.printStackTrace();

            return false;
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return turma;

    }

    @Override
    public Boolean alterar(Object object) {
        Turma turma = (Turma) object;

        PreparedStatement stmt = null;
        String sql = "update turma set idprofessor=?, nometurma=?, quantidadealunosturma=? where idturma=?";

        try {
            stmt = this.conn.prepareStatement(sql);

            stmt.setInt(1, turma.getIdProfessor());
            stmt.setString(2, turma.getNomeTurma());
            stmt.setInt(3, turma.getQtdAlunos());
            stmt.setInt(4, turma.getIdTurma());

            stmt.executeUpdate();
            return true;

        } catch (Exception e) {
            System.out.println("Erro ao alterar turma \n Erro: " + e.getMessage());
            e.printStackTrace();

            return false;
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
    
    public Integer recuperarIdTurma(int idUsuarioAluno) {
        
        Integer idTurma = null;
        Integer idAluno = null;
        
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        String sql1 = "select idaluno from aluno where idusuario =?";
        String sql2 = "select t.idturma from turma t, aluno a where a.idturma = t.idturma and a.idaluno =?";
        
        try {
            stmt = this.conn.prepareStatement(sql1);
            
            stmt.setInt(1, idUsuarioAluno);
            rs = stmt.executeQuery();
            if(rs.next()){
                idAluno = rs.getInt("idaluno");
                
                stmt = this.conn.prepareStatement(sql2);
                stmt.setInt(1, idAluno);
                rs = stmt.executeQuery();
                
                if(rs.next()){
                    idTurma = rs.getInt("idturma");
                }
            }
        } catch (Exception e) {
            System.out.println("Erro ao recuperar id \n Erro: "+e.getMessage());
            e.printStackTrace();
        }
        
        return idTurma;
    }

}
