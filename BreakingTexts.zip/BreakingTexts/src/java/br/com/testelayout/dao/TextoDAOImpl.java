/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.dao;

import br.com.testelayout.model.Texto;
import br.com.testelayout.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author PICHAU
 */
public class TextoDAOImpl implements GenericDAO {

    private Connection conn;

    public TextoDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.abrirconexao();
            System.out.println("Conectado com sucesso!");
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Override
    public boolean cadastrar(Object object) {
        Texto oTexto = (Texto) object;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Integer idAluno = null;

        String sqlIdAluno = "select idaluno from aluno where idusuario =?";
        String sqlVerificar = "select idtexto from texto where idaluno =? and idatividade =?";
        String sql = "insert into texto (idaluno, idatividade, titulotexto, caminhotexto, dataenviotexto, statuscorrecao)values(?,?,?,?,?,?)";

        Date data1 = new Date();

        try {
            stmt = this.conn.prepareStatement(sqlIdAluno);
            stmt.setInt(1, oTexto.getIdAluno());

            rs = stmt.executeQuery();
            if (rs.next()) {
                idAluno = rs.getInt("idaluno");

                stmt = this.conn.prepareStatement(sqlVerificar);
                stmt.setInt(1, idAluno);
                stmt.setInt(2, oTexto.getIdAtividade());

                rs = stmt.executeQuery();

                if (rs.next()) {

                    return false;

                } else {
                    stmt = this.conn.prepareStatement(sql);

                    stmt.setInt(1, idAluno);
                    stmt.setInt(2, oTexto.getIdAtividade());
                    stmt.setString(3, oTexto.getTituloTexto());
                    stmt.setString(4, oTexto.getCaminhoArquivoTexto());

                    //Recuperando a data e a hora atual
                    stmt.setDate(5, new java.sql.Date(data1.getTime()));
                    stmt.setString(6, oTexto.getStatusCorrecao());

                    stmt.execute();
                }

            }

        } catch (Exception e) {
            System.out.println("Erro ao enviar texto \n Erro: " + e.getMessage());
            e.printStackTrace();

            return false;
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return true;

    }

    public List<Object> listarTextosAtividade(Integer idAtividade) {
        List<Object> resultado = new ArrayList<>();

        Texto oTexto = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select * from texto where idatividade = ? order by statuscorrecao";

        try {
            stmt = this.conn.prepareStatement(sql);

            stmt.setInt(1, idAtividade);

            rs = stmt.executeQuery();
            while (rs.next()) {
                oTexto = new Texto();

                oTexto.setIdTexto(rs.getInt("idtexto"));
                oTexto.setIdAluno(rs.getInt("idaluno"));
                oTexto.setIdAtividade(rs.getInt("idatividade"));
                oTexto.setTituloTexto(rs.getString("titulotexto"));
                oTexto.setCaminhoArquivoTexto(rs.getString("caminhotexto"));
                oTexto.setDataEnvioTexto(rs.getDate("dataenviotexto"));
                oTexto.setStatusCorrecao(rs.getString("statuscorrecao"));
                oTexto.setPontuacaoTexto(rs.getDouble("pontuacaotexto"));
                oTexto.setComentarioTexto(rs.getString("comentariotexto"));

                resultado.add(oTexto);

            }

        } catch (Exception e) {
            System.out.println("Erro ao listar textos \n Erro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return resultado;
    }

    public List<Object> listarTextosAluno(Integer idUsuarioAluno) {
        List<Object> resultado = new ArrayList<>();

        Texto oTexto = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        Integer idAluno = null;

        String sqlIdAluno = "select idaluno from aluno where idusuario = ?";
        String sql = "select * from texto where idaluno = ?";

        try {

            stmt = this.conn.prepareStatement(sqlIdAluno);

            stmt.setInt(1, idUsuarioAluno);
            rs = stmt.executeQuery();

            if (rs.next()) {
                idAluno = rs.getInt("idaluno");

                stmt = this.conn.prepareStatement(sql);

                stmt.setInt(1, idAluno);

                rs = stmt.executeQuery();
                while (rs.next()) {
                    oTexto = new Texto();

                    oTexto.setIdTexto(rs.getInt("idtexto"));
                    oTexto.setIdAluno(rs.getInt("idaluno"));
                    oTexto.setIdAtividade(rs.getInt("idatividade"));
                    oTexto.setTituloTexto(rs.getString("titulotexto"));
                    oTexto.setCaminhoArquivoTexto(rs.getString("caminhotexto"));
                    oTexto.setDataEnvioTexto(rs.getDate("dataenviotexto"));
                    oTexto.setStatusCorrecao(rs.getString("statuscorrecao"));

                    resultado.add(oTexto);

                }

            }

        } catch (Exception e) {
            System.out.println("Erro ao listar textos \n Erro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return resultado;
    }

    @Override
    public List<Object> listar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public List<Object> listarMelhoresTextos(Integer idUsuarioAluno) {
        List<Object> resultado = new ArrayList<>();

        Texto oTexto = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        Integer idTurma = null;
        Integer idEscola = null;

        String sqlidTurma = "select idturma from aluno where idusuario = ?";
        String sqlidEscola = "select idescola from turma where idturma = ?";

        String sqlTopTxt = "select txt.* from texto txt, turma t, aluno a, escola e where txt.idaluno = a.idaluno "
                + "and a.idturma = t.idturma and e.idescola = ? and t.idescola = e.idescola and txt.pontuacaotexto between 9.2 and 10.0 order by dataenviotexto";

        try {
            stmt = this.conn.prepareStatement(sqlidTurma);
            stmt.setInt(1, idUsuarioAluno);
            rs = stmt.executeQuery();

            if (rs.next()) {
                idTurma = rs.getInt("idturma");

                stmt = this.conn.prepareStatement(sqlidEscola);
                stmt.setInt(1, idTurma);

                rs = stmt.executeQuery();
                if (rs.next()) {
                    idEscola = rs.getInt("idescola");

                    stmt = this.conn.prepareStatement(sqlTopTxt);
                    stmt.setInt(1, idEscola);

                    rs = stmt.executeQuery();
                    while (rs.next()) {
                        oTexto = new Texto();

                        oTexto.setTituloTexto(rs.getString("titulotexto"));
                        oTexto.setPontuacaoTexto(rs.getDouble("pontuacaotexto"));
                        oTexto.setCaminhoArquivoTexto(rs.getString("caminhotexto"));
                        oTexto.setComentarioTexto(rs.getString("comentariotexto"));

                        resultado.add(oTexto);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Erro ao listar melhores textos \n Erro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return resultado;
    }

    @Override
    public void excluir(int idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int idObject) {
        Texto texto = null;

        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "select * from texto where idtexto = ?";

        try {
            stmt = this.conn.prepareStatement(sql);

            stmt.setInt(1, idObject);

            rs = stmt.executeQuery();
            if (rs.next()) {
                texto = new Texto();

                texto.setCaminhoArquivoTexto(rs.getString("caminhotexto"));
                texto.setTituloTexto(rs.getString("titulotexto"));
                texto.setPontuacaoTexto(rs.getDouble("pontuacaotexto"));
                texto.setComentarioTexto(rs.getString("comentariotexto"));

            }

        } catch (Exception e) {
            System.out.println("Erro ao carregar texto \n Erro: " + e.getMessage());
            e.printStackTrace();

            return false;
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return texto;
    }

    @Override
    public Boolean alterar(Object object) {
        Texto texto = (Texto) object;

        ResultSet rs = null;
        PreparedStatement stmt = null;
        String sqlVerificar = "select pontuacaotexto from texto where idtexto =?";
        String sql = "update texto set pontuacaotexto=?, comentariotexto=?, statuscorrecao=? where idtexto=?";

        try {

            stmt = this.conn.prepareStatement(sqlVerificar);

            stmt.setInt(1, texto.getIdTexto());
            rs = stmt.executeQuery();

            if (rs.next()) {

                Double pontTexto = rs.getDouble("pontuacaotexto");
                if (pontTexto != 0.0) {
                    return false;
                } else {
                    stmt = this.conn.prepareStatement(sql);

                    stmt.setDouble(1, texto.getPontuacaoTexto());
                    stmt.setString(2, texto.getComentarioTexto());
                    stmt.setString(3, texto.getStatusCorrecao());
                    stmt.setInt(4, texto.getIdTexto());

                    stmt.executeUpdate();
                }
            }
        } catch (Exception e) {
            System.out.println("Erro ao alterar texto \n Erro: " + e.getMessage());
            e.printStackTrace();

            return false;
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return true;
    }

    public Double calcularMedia() {
        PreparedStatement stmt = null;
        ResultSet rs = null;

        Double somaTextos = 0.0;
        Double mediaTextos = null;
        Double nota;

        int i = 0;

        String sql = "select pontuacaotexto from texto";

        try {
            stmt = this.conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                nota = rs.getDouble("pontuacaotexto");
                somaTextos = somaTextos + nota;
                i++;
            }

            mediaTextos = somaTextos / i;

        } catch (Exception e) {
            System.out.println("Erro ao calcular media \n " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return mediaTextos;

    }

}
