/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.dao;


import br.com.testelayout.model.Escola;
import br.com.testelayout.model.ProfessorEscola;
import br.com.testelayout.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PICHAU
 */
public class ProfessorEscolaDAOImpl implements GenericDAO{
    
    private Connection conn;

    public ProfessorEscolaDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.abrirconexao();
            System.out.println("Conectado com sucesso!");
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Override
    public boolean cadastrar(Object object) {
        ProfessorEscola oProfessorEscola = (ProfessorEscola)object;
        
        PreparedStatement stmt = null;
        String sql = "insert into professor_escola(idprofessor,idescola)values(?,?)";
        
        try {
            stmt= this.conn.prepareStatement(sql);
            
            stmt.setInt(1, oProfessorEscola.getIdProfessor());
            stmt.setInt(2, oProfessorEscola.getIdEscola());
            
            stmt.execute();
            return true;
            
        } catch (Exception e) {
            System.out.println("Erro ao salvar na professor_escola \n Erro: "+e.getMessage());
            e.printStackTrace();
            
            return false;
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: "+e.getMessage());
                e.printStackTrace();
            }
            
        }
    }
    
     public List<Object> listarEscolas(Integer idUsuarioProfessor) {
       List<Object> resultado = new ArrayList<>();
        
        Escola oEscola = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        String sql = "select e.* from professor_escola pe, escola e, professor p, usuario u where u.idusuario = p.idusuario and p.idprofessor = pe.idprofessor and e.idescola = pe.idescola and u.idusuario=?";
        
         try {
             stmt = this.conn.prepareStatement(sql);
             
             stmt.setInt(1, idUsuarioProfessor);
             rs = stmt.executeQuery();
             while(rs.next()){
                 oEscola = new Escola();
                 
                 oEscola.setId(rs.getInt("idusuario"));
                 oEscola.setNome(rs.getString("nomeescola"));
                 
                 resultado.add(oEscola);
             }
             
         } catch (Exception e) {
             System.out.println("Erro ao listar escola \n Erro: "+e.getMessage());
             e.printStackTrace();
         }finally{
             try {
                 ConnectionFactory.fechar(conn, stmt, rs);
             } catch (Exception e) {
                 System.out.println("Erro ao fechar conexão \n Erro: "+e.getMessage());
                 e.printStackTrace();
             }
         }
         
         return resultado;
    }

    @Override
    public List<Object> listar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void excluir(int idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean alterar(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
