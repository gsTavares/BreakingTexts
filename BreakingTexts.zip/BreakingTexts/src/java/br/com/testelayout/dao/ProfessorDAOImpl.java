/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testelayout.dao;

import br.com.testelayout.model.Professor;
import br.com.testelayout.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PICHAU
 */
public class ProfessorDAOImpl implements GenericDAO {

    private Connection conn;

    public ProfessorDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.abrirconexao();
            System.out.println("Conectado com sucesso!");
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    public Integer cadastrarProfessor(Object object) {
        Professor oProfessor = (Professor) object;
        Integer idProfessor = null;
        String cpfProfessor = "";
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sqlVerificar = "select cpfprofessor from professor where cpfprofessor=?";
        String sqlNovoProfessor = "insert into professor(nomeprofessor,idadeprofessor,cpfprofessor,statusprofessor,idusuario)values(?,?,?,?,?)returning(idprofessor)";
        String recuperarProfessor = "select idprofessor from professor where cpfprofessor = ?";

        try {
            stmt = this.conn.prepareStatement(sqlVerificar);

            stmt.setString(1, oProfessor.getCpfProfessor());

            rs = stmt.executeQuery();
            if (rs.next()) {
                cpfProfessor = rs.getString("cpfprofessor");

                try {
                    stmt = this.conn.prepareStatement(recuperarProfessor);
                    stmt.setString(1, cpfProfessor);
                    rs = stmt.executeQuery();
                    if (rs.next()) {
                        idProfessor = rs.getInt("idprofessor");
                    }
                } catch (Exception e) {
                    System.out.println("Erro ao recuperar professor \n Erro: " + e.getMessage());
                    e.printStackTrace();

                }
            } else {
                stmt = this.conn.prepareStatement(sqlNovoProfessor);

                stmt.setString(1, oProfessor.getNome());
                stmt.setInt(2, oProfessor.getIdadeProfessor());
                stmt.setString(3, oProfessor.getCpfProfessor());
                stmt.setString(4, oProfessor.getStatusProfessor());
                
                try {
                    stmt.setInt(5, new UsuarioDAO().cadastrar(oProfessor));
                } catch (Exception e) {
                    System.out.println("Erro ao cadastrar professor/usuário \n Erro: " + e.getMessage());
                    e.printStackTrace();
                }
                rs = stmt.executeQuery();
                if (rs.next()) {
                    idProfessor = rs.getInt("idprofessor");
                }
            }

        } catch (Exception e) {
            System.out.println("Erro ao cadastrar professor no sistema \n Erro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);

            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return idProfessor;
    }

   
    @Override
    public List<Object> listar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void excluir(int idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int idObject) {
        Professor professor = null;
        Integer idUsuarioProfessor = null;

        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql1 = "select idusuario from professor where idprofessor = ?";
        String sql2 = "select * from professor where idusuario =?";

        try {
            stmt = this.conn.prepareStatement(sql1);

            stmt.setInt(1, idObject);

            rs = stmt.executeQuery();
            if (rs.next()) {
                idUsuarioProfessor = rs.getInt("idusuario");
                
                stmt = this.conn.prepareStatement(sql2);
                
                stmt.setInt(1, idUsuarioProfessor);
                rs = stmt.executeQuery();
                
                if(rs.next()){
                    professor = new Professor();
                    
                    professor.setId(idUsuarioProfessor);
                    professor.setNome(rs.getString("nomeprofessor"));
                    professor.setCpfProfessor(rs.getString("cpfprofessor"));
                    professor.setIdadeProfessor(rs.getInt("idadeprofessor"));
                    professor.setStatusProfessor(rs.getString("statusprofessor"));
                }
            }
        } catch (Exception e) {
            System.out.println("Erro ao cadastrar professor \n Erro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: "+e.getMessage());
                e.printStackTrace();
            }
        }
        return professor;
    }

    @Override
    public Boolean alterar(Object object) {
        Professor professor = (Professor)object;
        
        PreparedStatement stmt = null;
        String sql = "update professor set nomeprofessor=?, cpfprofessor=?, idadeprofessor=?, statusprofessor=? where idusuario=?";
        
        try {
            stmt = this.conn.prepareStatement(sql);
            
            stmt.setString(1, professor.getNome());
            stmt.setString(2, professor.getCpfProfessor());
            stmt.setInt(3, professor.getIdadeProfessor());
            stmt.setString(4, professor.getStatusProfessor());
            stmt.setInt(5, professor.getId());
            
            try {
                if(new UsuarioDAO().alterarUsuario(professor)){
                    stmt.executeUpdate();
                    return true;
                }else{
                    return false;
                }
            } catch (Exception e) {
                System.out.println("Erro ao alterar usuário - Professor \n Erro: "+e.getMessage());
                e.printStackTrace();
                
                return false;
            }
                    
        } catch (Exception e) {
            System.out.println("Erro ao alterar professor \n Erro: "+e.getMessage());
            e.printStackTrace();
            
            return false;
        }finally{
            try {
                ConnectionFactory.fechar(conn, stmt);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: "+e.getMessage());
                e.printStackTrace();
            }
        }
        
    }

    @Override
    public boolean cadastrar(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public List<Object> ListarProfessorEscola(Integer idUsuarioEscola) {
        List<Object> resultado = new ArrayList<>();

        Professor oProfessor = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select pe.idprofessor, pe.idescola, p.nomeprofessor, p.cpfprofessor, p.idadeprofessor, p.statusprofessor from professor_escola pe, professor p, escola e where pe.idprofessor = p.idprofessor and e.idusuario = ? and pe.idescola = e.idescola order by p.nomeprofessor;";

        try {

            stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, idUsuarioEscola);
            rs = stmt.executeQuery();

            while (rs.next()) {
                oProfessor = new Professor();

                oProfessor.setId(rs.getInt("idprofessor"));
                oProfessor.setNome(rs.getString("nomeprofessor"));
                oProfessor.setCpfProfessor(rs.getString("cpfprofessor"));
                oProfessor.setIdadeProfessor(rs.getInt("idadeprofessor"));
                oProfessor.setIdadeProfessor(rs.getInt("idadeprofessor"));
                oProfessor.setStatusProfessor(rs.getString("statusprofessor"));

                resultado.add(oProfessor);
            }

        } catch (Exception e) {
            System.out.println("Erro ao cadastrar professor \n Erro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return resultado;
    }
    
    
    
     public List<Object> ListarProfessoresDisponiveis(Integer idUsuarioEscola) {
        List<Object> resultado = new ArrayList<>();

        Professor oProfessor = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select pe.idprofessor, pe.idescola, p.nomeprofessor, p.cpfprofessor, p.idadeprofessor, p.statusprofessor from professor_escola pe, professor p, escola e where pe.idprofessor = p.idprofessor and e.idusuario = ? and pe.idescola = e.idescola and p.statusprofessor = 'Ativo' order by p.nomeprofessor;";

        try {

            stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, idUsuarioEscola);
            rs = stmt.executeQuery();

            while (rs.next()) {
                oProfessor = new Professor();

                oProfessor.setId(rs.getInt("idprofessor"));
                oProfessor.setNome(rs.getString("nomeprofessor"));
                oProfessor.setCpfProfessor(rs.getString("cpfprofessor"));
                oProfessor.setIdadeProfessor(rs.getInt("idadeprofessor"));
                oProfessor.setIdadeProfessor(rs.getInt("idadeprofessor"));
                oProfessor.setStatusProfessor(rs.getString("statusprofessor"));

                resultado.add(oProfessor);
            }

        } catch (Exception e) {
            System.out.println("Erro ao cadastrar professor \n Erro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão \n Erro: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return resultado;
    }
     
     
     
}
